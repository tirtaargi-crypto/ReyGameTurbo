package com.reygameturbo.rgt

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.widget.*

class TurboOverlayService : Service() {
    private var wm: WindowManager? = null
    private var panel: View? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        remove()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mode = intent?.getStringExtra("mode") ?: "sidebar"
        panel = if (mode == "crosshair") crosshair() else sidebar()
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val lp = WindowManager.LayoutParams(
            if (mode == "crosshair") 180 else 230,
            if (mode == "crosshair") 180 else 260,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        wm?.addView(panel, lp)
        return START_STICKY
    }

    private fun crosshair(): View {
        val f = FrameLayout(this)
        val c = TextView(this)
        c.text = "✚"
        c.textSize = 48f
        c.gravity = Gravity.CENTER
        c.setTextColor(Color.WHITE)
        f.addView(c, FrameLayout.LayoutParams(-1, -1))
        f.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) remove()
            true
        }
        return f
    }

    private fun sidebar(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(18, 18, 18, 18)
        val bg = GradientDrawable()
        bg.setColor(Color.argb(235, 12, 16, 24))
        bg.cornerRadius = 28f
        box.background = bg

        val title = TextView(this)
        title.text = "RO  TURBO"
        title.textSize = 18f
        title.setTextColor(Color.rgb(0,229,255))
        box.addView(title)

        val info = TextView(this)
        info.text = "\nTURBO\nCROSSHAIR\nSMOOTH\nCLEANUP"
        info.textSize = 14f
        info.setTextColor(Color.WHITE)
        box.addView(info)

        val close = Button(this)
        close.text = "CLOSE"
        close.setOnClickListener { remove() }
        box.addView(close)
        return box
    }

    private fun remove() {
        panel?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        remove()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
