# ReyGameTurbo (RGT)

A dark gaming dashboard inspired by the feature set commonly found in Android gaming modes.

## Features
- Game/app library and launcher
- Shizuku running/permission status
- Shizuku-backed shell execution
- Turbo profile using supported Settings keys
- Smooth profile using pointer-speed setting
- Selected-app force-stop cleanup
- Crosshair overlay
- Floating gaming sidebar
- Android 16 / SDK 35
- Kotlin JVM target 17
- GitHub Actions ready

## Important
This project does not implement auto-aim, target tracking, memory injection, or anti-cheat bypass.

Vendor-specific touch sampling and proprietary performance properties are not universal Android APIs. The app only applies explicit settings it can execute and reports command output instead of claiming a fake boost.

Shizuku access is checked before privileged operations. ADB/Shizuku permissions are limited and vary by Android version/device.
